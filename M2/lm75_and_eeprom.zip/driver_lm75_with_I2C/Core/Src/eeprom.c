#include "eeprom.h"
#define EEPROM_ADDR (0x50<<1)

I2C_HandleTypeDef * eeprom_i2c;

void EEPROM_Init(I2C_HandleTypeDef *hi2c){
	if(hi2c != NULL){
		eeprom_i2c = hi2c;
	}
}

HAL_StatusTypeDef EEPROM_WriteByte(uint16_t mem_addr,uint8_t data)
{
	return HAL_I2C_Mem_Write(eeprom_i2c,EEPROM_ADDR,mem_addr,I2C_MEMADD_SIZE_16BIT,&data,1,1000);
}

HAL_StatusTypeDef EEPROM_ReadByte(uint16_t mem_addr,uint8_t *data)
{
	return HAL_I2C_Mem_Read(eeprom_i2c,EEPROM_ADDR,mem_addr,I2C_MEMADD_SIZE_16BIT,data,1,1000);
}

HAL_StatusTypeDef EEPROM_WriteBuffer(uint16_t mem_addr,uint8_t *buffer,uint16_t size)
{
	return HAL_I2C_Mem_Write(eeprom_i2c,EEPROM_ADDR,mem_addr,I2C_MEMADD_SIZE_16BIT,buffer,size,1000);
}

HAL_StatusTypeDef EEPROM_ReadBuffer(uint16_t mem_addr,uint8_t *buffer,uint16_t size)
{
	return HAL_I2C_Mem_Read(eeprom_i2c,EEPROM_ADDR,mem_addr,I2C_MEMADD_SIZE_16BIT,buffer,size,1000);
}

HAL_StatusTypeDef EEPROM_IsReady(void)
{
	return HAL_I2C_IsDeviceReady(eeprom_i2c,EEPROM_ADDR,10,1000);
}
